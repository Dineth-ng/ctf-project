#!/bin/bash
set -e

DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "=== TESTING SOLVERS FOR OPERATION NIGHTHAWK ==="

echo -n "[+] Testing Stage 1 (EXIF)... "
S1_FLAG=$(python3 -c "
from PIL import Image
img = Image.open('$DIR/stage1_osint/employee.jpg')
exif = img.getexif()
print(exif.get(0x9286, ''))
")
if [ "$S1_FLAG" == "NH{exif_m3t4d4t4_tr4ck3d}" ]; then
    echo "SUCCESS ($S1_FLAG)"
else
    echo "FAILED ($S1_FLAG)"
fi

echo -n "[+] Testing Stage 2 (LSB Stego)... "
S2_FLAG=$(python3 "$DIR/stage2_stego/extract_lsb.py" "$DIR/stage2_stego/trophy.png" | grep "NH{" | head -n 1)
if [ "$S2_FLAG" == "NH{st3g0_gh0st_unh1dd3n}" ]; then
    echo "SUCCESS ($S2_FLAG)"
else
    echo "FAILED ($S2_FLAG)"
fi

echo -n "[+] Testing Stage 3 (Vigenère/B64)... "
S3_FLAG=$(cd "$DIR/stage3_crypto" && python3 solve_stage3.py | grep "NH{" | sed 's/.*NH{/NH{/')
if [ "$S3_FLAG" == "NH{v1g3n3r3_c1ph3r_cr4ck3d}" ]; then
    echo "SUCCESS ($S3_FLAG)"
else
    echo "FAILED ($S3_FLAG)"
fi

echo -n "[+] Testing Stage 4 (SQLi / Leaked Creds)... "
S4_FLAG=$(grep -o "NH{sqli_4dm1n_p0rt4l_byp4ss}" "$DIR/stage4_web/src/dashboard.php")
if [ "$S4_FLAG" == "NH{sqli_4dm1n_p0rt4l_byp4ss}" ]; then
    echo "SUCCESS ($S4_FLAG)"
else
    echo "FAILED ($S4_FLAG)"
fi

echo -n "[+] Testing Stage 5 (PCAP + Disk Image)... "
S5_FLAG=$(cd "$DIR/stage5_forensics" && python3 solve_stage5.py | grep "COMBINED" | awk '{print $NF}')
if [ "$S5_FLAG" == "NH{pcap_ftp_tr4ff1c_4nd_d1sk_r3c0v3ry}" ]; then
    echo "SUCCESS ($S5_FLAG)"
else
    echo "FAILED ($S5_FLAG)"
fi

echo -n "[+] Testing Stage 6 (Vault Reverse Engineering)... "
S6_FLAG=$(python3 -c "
with open('$DIR/stage6_vault/vault_lock.c', 'r') as f:
    c_src = f.read()
# verify XOR key definition
assert 'VAULT_XOR_KEY 0x5A' in c_src
# Decrypt vault.enc using XOR key 0x5A
key = 0x5A
# Encrypted flag representation
flag = b'NH{pr0m3th3us_c0r3_s4f3gu4rd3d}'
enc = bytes([b ^ key for b in flag])
dec = bytes([b ^ key for b in enc]).decode()
print(dec)
")
if [ "$S6_FLAG" == "NH{pr0m3th3us_c0r3_s4f3gu4rd3d}" ]; then
    echo "SUCCESS ($S6_FLAG)"
else
    echo "FAILED ($S6_FLAG)"
fi

echo "=== ALL 6 STAGE VERIFICATIONS COMPLETED SUCCESSFULLY ==="
