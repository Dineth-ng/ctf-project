#!/bin/bash
set -e

echo "=========================================================="
echo "   OPERATION NIGHTHAWK: THE GHOSTBYTE FILES DEPLOYER     "
echo "=========================================================="

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "[-] Docker is not installed. Installing Docker..."
    sudo apt update && sudo apt install -y docker.io docker-compose
    sudo systemctl enable --now docker
    sudo usermod -aG docker "$USER"
    echo "[!] Docker installed. If permission errors occur, relog or run with sudo."
fi

# Ensure docker daemon is active
if ! systemctl is-active --quiet docker; then
    echo "[+] Starting Docker daemon..."
    sudo systemctl start docker
fi

echo "[+] Building and launching all CTF services via Docker Compose..."
cd "$(dirname "$0")/.."
sudo docker-compose up -d --build

echo ""
echo "=========================================================="
echo "          OPERATION NIGHTHAWK IS NOW ONLINE!              "
echo "=========================================================="
echo "[*] CTFd Scoreboard:        http://localhost:8000"
echo "[*] Stage 1 & 2 Web Portal: http://localhost:80"
echo "[*] Stage 3 Artifact:       ./stage3_crypto/chat_log.txt"
echo "[*] Stage 4 Shadow C2 App:  http://localhost:8080"
echo "[*] Stage 5 Forensics:      ./stage5_forensics/ (exfil.pcap, disk.img)"
echo "[*] Stage 6 Vault (SSH):    ssh -p 2222 runner@localhost (pass: nighthawk_guest)"
echo "=========================================================="
echo "To stop the environment:  sudo docker-compose down"
echo "To view service logs:     sudo docker-compose logs -f"
echo "=========================================================="
